#include <stdio.h>
#include <math.h>

int main(){
    int mean = 0;float alpha =0.9;int num = 3;
    mean = num*alpha + (1-alpha)*mean;
    printf("%d",mean);
    return 0;
}