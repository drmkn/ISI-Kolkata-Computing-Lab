#include<stdio.h>
#include<math.h>
int main(){
    printf("%f",sqrt(2));
    return 0;
}