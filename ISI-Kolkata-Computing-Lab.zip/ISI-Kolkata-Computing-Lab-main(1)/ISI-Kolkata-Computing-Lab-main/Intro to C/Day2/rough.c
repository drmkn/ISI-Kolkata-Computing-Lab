#include<stdio.h>
int main(){
    char name[100];
    printf("Print your name:\n");
    scanf("%s", name);
    printf("Your name is %s\n", name);


    return 0;
}
