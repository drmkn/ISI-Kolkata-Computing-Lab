#include<stdio.h>
#define BUF_LEN 100
#define INCR ++
#define SQR(X) X*X
#define SQR1(x) x*x+1
#define Malloc(n,type) (type*)malloc(n*sizeof(type)
int main(){
    /*int x[BUF_LEN+0.1];
    int a[1BUF_LEN];
    int b[BUF_LEN00];
    printf("%ld\n",sizeof(x));
    printf("%ld\n",sizeof(a));
    printf("%ld\n",sizeof(b));*/
    /*int a =1;
    a INCR;
    printf("%d\n",a);*/
    int x;
    printf("%d %d\n", SQR1(5+1),SQR('1'));
    printf("%d %d\n", SQR1(5),SQR1('1'));
    

}
