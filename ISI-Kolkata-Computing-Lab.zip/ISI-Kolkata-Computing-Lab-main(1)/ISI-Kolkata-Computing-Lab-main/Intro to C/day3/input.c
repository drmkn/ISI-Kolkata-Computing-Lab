#include<stdio.h>
int main(){
    int c;
    int n,status;
    //while(EOF !=(c = getchar())){
     //    putchar(c);
    //}
    
    
    while(1){
      //scanf("%d", &n);
      status = scanf("%d", &n);
      //printf("%d\n",n);
      printf("%d(status = %d)\n",n, status);
      //if(status == 0){ // kind of fix 
        //getchar();
      //} else {
        //  continue;}
      
    
    
    
    
    }
    return 0;
}

