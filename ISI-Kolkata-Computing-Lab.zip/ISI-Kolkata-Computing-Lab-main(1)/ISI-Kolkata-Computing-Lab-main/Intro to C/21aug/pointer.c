#include<stdio.h>
int main(){
    //int x =400;
    //int y = 300;
    //int *p;
    //p = &x;
    //printf("%lu\n",p);
    //p = &y;
    //printf("%lu\n",p);
    //x = *p;
    //printf("%lu\n",x);
    //printf("%d %lu %d\n",p,p,*p);
    //*p = *p + 1;
    //printf("%lu %lu %d",p, p+1,p+1);
    //char c, *cp;
    //long int i, *ip;
    
    //cp = &c; ip = &i;
    //printf("%lu\n",cp);
    //printf("%lu\n",cp+1);
    //printf("%lu\n",cp-1);
    //printf("%lu\n",ip);
    //printf("%lu\n",ip+1);
    //printf("%lu\n",ip-1);
    //int *s,*t;
    //int i;
    //for (i=0; i < 20; i++) printf("abcdefghijklmnop\n" + i);
    char *s = "hello\n";
    printf("hello\n");
    printf(s);
    printf(s+1);
    printf(s+2);
   
        
    

    return 0;
}
