#include<stdio.h>
int main(){
    int s;
    char k;
    while(EOF != (s = fgetc(stdin))){
          //k = s;
          printf("%c %d\n",s,s);
    
    
    
    }





    return 0;
}
