#include<stdio.h>
int main(){
    int *s;
    scanf("%c",&s[0]);
    printf("%s\n",s);
    scanf("%s",&s[2]);
    printf("%s",s);









return 0;
}
