#ifndef A_H
#define A_H
#include "b.h"
#endif
