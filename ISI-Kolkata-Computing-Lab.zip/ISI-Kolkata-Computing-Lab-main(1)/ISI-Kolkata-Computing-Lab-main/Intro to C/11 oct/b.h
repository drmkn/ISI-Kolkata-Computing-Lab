#ifndef B_H
#define B_H
#include "a.h"
#endif