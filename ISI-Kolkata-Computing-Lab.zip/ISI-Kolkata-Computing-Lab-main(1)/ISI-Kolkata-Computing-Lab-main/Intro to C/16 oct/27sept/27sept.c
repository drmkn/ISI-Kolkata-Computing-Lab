#include<stdio.h>
#include<stdlib.h>

int main(int ac, char **av){
    //int i;
    //printf("ac=%d\n",ac);
    //for(i=0;i<ac;i++) {printf("argv[%d]=%s\n",i,av[i]);}
    printf("%d\n",atoi("10000.2"));

    return 0;
}