#include <stdio.h>
int main(void)
{
    /* declarations */
    unsigned char c;
    unsigned int a, b, ab, o;
    unsigned int n, i;
    a = 0; b = 0; ab = 0; o = 0;
    printf("Enter the number of students: ");
    scanf("%d", &n);
    
    c = getchar();
    printf("%c\n",c);
    
    c = getchar();
    printf("%c\n",c);
    
    c = getchar();
    printf("%c\n",c);
    
    c = getchar();
    printf("%c\n",c);
    
    
    
    return 0;
    
}
