#include<stdio.h>
#include<ctype.h>

#include<stdlib.h>
int main(){
   int i =0;
   srand(10);
   for(;i < 10; i++){
      printf("%d\n",rand());



   }





   return 0;




}
