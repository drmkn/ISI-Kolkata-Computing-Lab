#ifndef QUEUE_H
#define QUEUE_H

typedef int DATA;
typedef struct{
    int capacity, front, rear;
    DATA *elements;
    } QUEUE;



#endif